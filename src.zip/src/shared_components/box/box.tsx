type BoxProps = {
    title?: string;
    children: React.ReactNode;
};

function Box({ title, children }: BoxProps) {
    return (
        <div className="bg-white/90 rounded-2xl shadow-lg p-6 backdrop-blur-sm">
            {title && <h2 className="text-xl font-semibold mb-4 text-gray-800">{title}</h2>}
            {children}
        </div>
    );
}

export default Box;
