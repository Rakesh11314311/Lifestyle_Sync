import Card from '../../shared_components/cards/card'

type cardInfo = {
    name: string,
    description: string,
}

const cardList: cardInfo[] = [
    {
        name: "Health",
        description: "Track your daily Intake calories",
    },
    {
        name: "Finance",
        description: "Track your monthly Financial Expenses",
    },
    {
        name: "Entertainment",
        description: "Weekend Entertainment Recommendations",
    },
];

export default function Home() {
    return (
        <>
            <div className='flex flex-wrap flex-col flex justify-center items-center'>
                <h1 className='Heading text-3xl font-bold'>Hey There, What Do You want to Focus on Today</h1>
                <div className='flex flex-wrap'>
                    {cardList.map((card, index) => (
                        <Card key={index} name={card.name} description={card.description} />
                    ))}
                </div>
            </div>

        </>
    )
}