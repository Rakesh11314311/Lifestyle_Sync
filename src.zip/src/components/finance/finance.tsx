import DoughnutChart from '../../shared_components/doughnut_chart/doughnut_chart';
import Box from '../../shared_components/box/box';
import { useSelector } from 'react-redux'
import type { RootState } from '../home/main';

function Finance() {
    const finance = useSelector((state: RootState) => state.finance);

    return (
        <>
            <h1 className='Heading text-3xl font-bold'>Finance</h1>

            <div className="bg-white rounded-xl shadow-md p-1 w-full max-w-md">
                <Box title="Spending Overview">
                    <canvas id="spendingChart" className="w-full h-64" />
                    <DoughnutChart />
                </Box>
            </div>
            <div>

            </div>


        </>
    )
}

export default Finance
