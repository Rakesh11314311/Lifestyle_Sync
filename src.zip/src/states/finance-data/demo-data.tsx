type expense = {
    tag: string;
    amount: number;
}

export type finObject = {
    point: number; // total monthly earning
    data: expense[]; //pair of expense type and value
};

export const demoFinList: finObject[] = [
    {
        point: 50000,
        data: [
            { tag: "Housing", amount: 18000 },
            { tag: "Food", amount: 6000 },
            { tag: "Transportation", amount: 4000 },
            { tag: "Savings", amount: 20000 },
            { tag: "Entertainment", amount: 2000 }
        ]
    },
    {
        point: 45000,
        data: [
            { tag: "Housing", amount: 15000 },
            { tag: "Food", amount: 5000 },
            { tag: "Transportation", amount: 3000 },
            { tag: "Savings", amount: 2000 },
            { tag: "Healthcare", amount: 4000 },
            { tag: "Miscellaneous", amount: 1000 }
        ]
    },
    {
        point: 60000,
        data: [
            { tag: "Housing", amount: 20000 },
            { tag: "Food", amount: 8000 },
            { tag: "Transportation", amount: 5000 },
            { tag: "Savings", amount: 25000 },
            { tag: "Clothing", amount: 2000 }
        ]
    },
    {
        point: 35000,
        data: [
            { tag: "Housing", amount: 12000 },
            { tag: "Food", amount: 4000 },
            { tag: "Debt", amount: 3000 },
            { tag: "Entertainment", amount: 3000 },
            { tag: "Savings", amount: 10000 },
            { tag: "Education", amount: 3000 }
        ]
    }
];

