import { createSlice } from "@reduxjs/toolkit";
import { demoFinList } from "./demo-data";
import type { finObject } from "./demo-data";

const initialState: finObject[] = demoFinList;

const finSlice = createSlice({
    //following name will be the name will be how we get access to this slice "state.whatever_name_you_put_down_here"
    name: "finance",
    initialState,
    //following will conatin reducer functions that will work on current state
    reducers: {
    }
})

export const { } = finSlice.actions;
export default finSlice.reducer;
